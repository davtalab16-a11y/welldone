import React, { useRef } from 'react';
import { Download, Edit3 } from 'lucide-react';
import html2canvas from 'html2canvas';
import type { Story } from '../types';

interface Props {
  stories: Story[];
  onUpdateText: (id: string, text: string) => void;
}

export const StoryPreview: React.FC<Props> = ({ stories, onUpdateText }) => {
  const storyRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});

  const downloadStory = async (id: string, index: number) => {
    const element = storyRefs.current[id];
    if (!element) return;

    try {
      const canvas = await html2canvas(element, {
        scale: 2, // High quality
        useCORS: true,
        backgroundColor: null,
      });

      const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
      const link = document.createElement('a');
      link.download = `story-${index + 1}.jpg`;
      link.href = dataUrl;
      link.click();
    } catch (error) {
      console.error('Error downloading story:', error);
    }
  };

  const getJustifyContent = (position: string) => {
    switch (position) {
      case 'top': return 'flex-start';
      case 'bottom': return 'flex-end';
      default: return 'center';
    }
  };

  if (stories.length === 0) return null;

  return (
    <div className="space-y-8 mt-12">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">خروجی استوری‌ها</h2>
        <p className="text-slate-400">برای ویرایش روی متن کلیک کنید</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
        {stories.map((story, index) => (
          <div key={story.id} className="space-y-4 group">
            <div className="relative aspect-[9/16] rounded-2xl overflow-hidden shadow-2xl border border-white/10 group-hover:border-fuchsia-500/50 transition-colors">
              {/* This is the container that will be captured by html2canvas */}
              <div
                ref={(el) => { storyRefs.current[story.id] = el; }}
                className="absolute inset-0 w-full h-full flex flex-col"
                style={{ background: story.backgroundStyle }}
              >
                {/* Background Image */}
                <div className="absolute inset-0 z-0">
                  <img
                    src={story.imageUrl}
                    alt={`Story ${index + 1}`}
                    className="w-full h-full object-cover"
                    crossOrigin="anonymous"
                  />
                  <div 
                    className="absolute inset-0"
                    style={{
                      background: `linear-gradient(to top, rgba(0,0,0,0.8) 0%, rgba(0,0,0,${story.overlayOpacity}) 50%, rgba(0,0,0,0.4) 100%)`
                    }}
                  />
                </div>

                {/* Text Content */}
                <div 
                  className="relative z-10 flex flex-col h-full w-full p-8"
                  style={{ justifyContent: getJustifyContent(story.typography.position) }}
                >
                  <textarea
                    value={story.text}
                    onChange={(e) => onUpdateText(story.id, e.target.value)}
                    className="w-full bg-transparent border-none resize-none overflow-hidden focus:outline-none focus:ring-1 focus:ring-white/20 rounded p-2"
                    style={{
                      fontFamily: story.typography.fontFamily,
                      fontSize: `${story.typography.fontSize}px`,
                      color: story.typography.color,
                      fontWeight: story.typography.weight,
                      fontStyle: story.typography.style,
                      textShadow: story.typography.textShadow,
                      textAlign: story.typography.textAlign,
                      lineHeight: '1.4',
                    }}
                    rows={story.text.split('\n').length || 1}
                  />
                </div>
              </div>

              {/* Edit Icon Overlay (not downloaded) */}
              <div className="absolute top-4 right-4 z-20 opacity-0 group-hover:opacity-100 transition-opacity bg-black/50 p-2 rounded-full backdrop-blur-sm pointer-events-none">
                <Edit3 className="w-4 h-4 text-white" />
              </div>
            </div>

            <button
              onClick={() => downloadStory(story.id, index)}
              className="w-full py-3 rounded-xl glass-card flex items-center justify-center gap-2 text-white hover:bg-white/10 transition-colors font-medium"
            >
              <Download className="w-4 h-4" />
              دانلود استوری {index + 1}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};