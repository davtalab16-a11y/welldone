import React from 'react';
import { Palette, AlignLeft, AlignCenter, AlignRight, AlignJustify } from 'lucide-react';
import type { TypographyStyle } from '../types';

interface Props {
  typography: TypographyStyle;
  onTypographyChange: (style: TypographyStyle) => void;
}

const fonts = [
  { name: 'Vazirmatn', label: 'وزیرمتن (مدرن)' },
  { name: 'Inter', label: 'Inter (انگلیسی)' },
  { name: 'Playfair Display', label: 'Playfair (کلاسیک)' },
];

const weights = [
  { value: '300', label: 'نازک' },
  { value: '400', label: 'عادی' },
  { value: '500', label: 'متوسط' },
  { value: '700', label: 'ضخیم' },
  { value: '900', label: 'خیلی ضخیم' },
];

export const StyleEditor: React.FC<Props> = ({ typography, onTypographyChange }) => {
  const handleChange = <K extends keyof TypographyStyle>(key: K, value: TypographyStyle[K]) => {
    onTypographyChange({ ...typography, [key]: value });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Palette className="w-5 h-5 text-indigo-400" />
        <h2 className="text-xl font-bold text-white">استایل و تایپوگرافی</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">فونت</label>
            <select
              value={typography.fontFamily}
              onChange={(e) => handleChange('fontFamily', e.target.value)}
              className="w-full glass-input rounded-xl px-4 py-3 text-white appearance-none cursor-pointer"
            >
              {fonts.map((f) => (
                <option key={f.name} value={f.name} className="bg-slate-800 text-white">
                  {f.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">وزن فونت</label>
            <select
              value={typography.weight}
              onChange={(e) => handleChange('weight', e.target.value as TypographyStyle['weight'])}
              className="w-full glass-input rounded-xl px-4 py-3 text-white appearance-none cursor-pointer"
            >
              {weights.map((w) => (
                <option key={w.value} value={w.value} className="bg-slate-800 text-white">
                  {w.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2 flex justify-between">
              <span>اندازه متن</span>
              <span className="text-indigo-400">{typography.fontSize}px</span>
            </label>
            <input
              type="range"
              min="16"
              max="72"
              value={typography.fontSize}
              onChange={(e) => handleChange('fontSize', parseInt(e.target.value))}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
            />
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">رنگ متن</label>
            <div className="flex items-center gap-3">
              <input
                type="color"
                value={typography.color}
                onChange={(e) => handleChange('color', e.target.value)}
                className="h-12 w-full glass-input rounded-xl cursor-pointer p-1"
              />
              <span className="text-sm font-mono text-slate-400 w-20">{typography.color}</span>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">چینش متن</label>
            <div className="flex gap-2 p-1 glass-input rounded-xl">
              {(
                [
                  { v: 'right', i: <AlignRight className="w-5 h-5" /> },
                  { v: 'center', i: <AlignCenter className="w-5 h-5" /> },
                  { v: 'left', i: <AlignLeft className="w-5 h-5" /> },
                  { v: 'justify', i: <AlignJustify className="w-5 h-5" /> },
                ] as const
              ).map((align) => (
                <button
                  key={align.v}
                  onClick={() => handleChange('textAlign', align.v)}
                  className={`flex-1 flex justify-center py-2 rounded-lg transition-colors ${
                    typography.textAlign === align.v ? 'bg-indigo-500/20 text-indigo-400' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {align.i}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">جایگاه متن</label>
            <select
              value={typography.position}
              onChange={(e) => handleChange('position', e.target.value as TypographyStyle['position'])}
              className="w-full glass-input rounded-xl px-4 py-3 text-white appearance-none cursor-pointer"
            >
              <option value="top" className="bg-slate-800">بالا</option>
              <option value="middle" className="bg-slate-800">مرکز</option>
              <option value="bottom" className="bg-slate-800">پایین</option>
            </select>
          </div>
        </div>
      </div>

      {/* Preview Box */}
      <div className="mt-6 p-6 rounded-2xl border border-white/10 bg-black/20 flex items-center justify-center min-h-[120px] overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 to-fuchsia-500/10" />
        <p
          className="relative z-10 transition-all duration-300"
          style={{
            fontFamily: typography.fontFamily,
            fontSize: `${Math.min(typography.fontSize, 40)}px`,
            color: typography.color,
            fontWeight: typography.weight,
            fontStyle: typography.style,
            textShadow: typography.textShadow,
            textAlign: typography.textAlign,
          }}
        >
          پیش‌نمایش استایل متن شما
        </p>
      </div>
    </div>
  );
};