import React, { useCallback } from 'react';
import { UploadCloud, X, Image as ImageIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import type { UploadedImage } from '../types';

interface Props {
  images: UploadedImage[];
  onAddImage: (image: UploadedImage) => void;
  onRemoveImage: (id: string) => void;
}

export const ImageUploader: React.FC<Props> = ({ images, onAddImage, onRemoveImage }) => {
  const processFiles = useCallback((files: File[]) => {
    const remainingSlots = 10 - images.length;
    const filesToAdd = files.slice(0, remainingSlots);

    filesToAdd.forEach((file) => {
      const url = URL.createObjectURL(file);
      onAddImage({ id: `img-${Date.now()}-${file.name}`, url, file });
    });
  }, [images, onAddImage]);

  const handleDrop = useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      const files = Array.from(e.dataTransfer.files).filter((file) =>
        file.type.startsWith('image/')
      );
      processFiles(files);
    },
    [processFiles]
  );

  const handleFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files) {
        const files = Array.from(e.target.files);
        processFiles(files);
      }
    },
    [processFiles]
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <ImageIcon className="w-5 h-5 text-pink-500" />
          <span>آپلود تصاویر رفرنس</span>
        </h2>
        <span className="text-sm font-medium px-3 py-1 rounded-full glass-card text-pink-300">
          {images.length} / 10 تصویر
        </span>
      </div>

      <div
        onDrop={handleDrop}
        onDragOver={(e) => e.preventDefault()}
        className="relative group border-2 border-dashed border-white/20 rounded-2xl p-8 transition-all hover:border-pink-500/50 hover:bg-pink-500/5 bg-black/20 backdrop-blur-sm cursor-pointer overflow-hidden flex flex-col items-center justify-center min-h-[200px]"
      >
        <input
          type="file"
          multiple
          accept="image/*"
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
          onChange={handleFileInput}
          disabled={images.length >= 10}
        />
        
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />

        <div className="flex flex-col items-center gap-4 text-slate-400 group-hover:text-slate-300 transition-colors z-20">
          <div className="p-4 rounded-full bg-white/5 group-hover:bg-pink-500/20 group-hover:scale-110 transition-all duration-300">
            <UploadCloud className="w-8 h-8 group-hover:text-pink-400" />
          </div>
          <div className="text-center">
            <p className="text-lg font-medium text-white mb-1">
              {images.length >= 10 ? 'ظرفیت تکمیل است' : 'تصاویر را اینجا رها کنید'}
            </p>
            <p className="text-sm">یا برای انتخاب کلیک کنید (حداکثر ۱۰ تصویر)</p>
          </div>
        </div>
      </div>

      {images.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 mt-6">
          <AnimatePresence>
            {images.map((image) => (
              <motion.div
                key={image.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="relative aspect-[3/4] rounded-xl overflow-hidden group border border-white/10 shadow-lg"
              >
                <img
                  src={image.url}
                  alt="upload"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-start justify-end p-2">
                  <button
                    onClick={() => onRemoveImage(image.id)}
                    className="p-1.5 bg-rose-500/80 hover:bg-rose-500 text-white rounded-full backdrop-blur-md transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
};