import React from 'react';
import { Target, MessageSquare, ListPlus } from 'lucide-react';
import type { Scenario } from '../types';

interface Props {
  scenario: Scenario;
  onScenarioChange: (scenario: Scenario) => void;
  storyCount: number;
  onStoryCountChange: (count: number) => void;
}

export const ScenarioInput: React.FC<Props> = ({
  scenario,
  onScenarioChange,
  storyCount,
  onStoryCountChange,
}) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Target className="w-5 h-5 text-fuchsia-500" />
        <h2 className="text-xl font-bold text-white">سناریو و هدف کمپین</h2>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-2">
            <span>هدف اصلی استوری‌ها (مثلا: فروش ویژه یلدا)</span>
          </label>
          <input
            type="text"
            value={scenario.campaignGoal}
            onChange={(e) => onScenarioChange({ ...scenario, campaignGoal: e.target.value })}
            className="w-full glass-input rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:ring-2 focus:ring-fuchsia-500/50"
            placeholder="هدف کمپین خود را وارد کنید..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-2">
            <MessageSquare className="w-4 h-4" />
            <span>پیام اصلی (تیتر یک)</span>
          </label>
          <input
            type="text"
            value={scenario.mainMessage}
            onChange={(e) => onScenarioChange({ ...scenario, mainMessage: e.target.value })}
            className="w-full glass-input rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:ring-2 focus:ring-fuchsia-500/50"
            placeholder="جمله‌ای که می‌خواهید بیشترین توجه را جلب کند..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-2">
            <ListPlus className="w-4 h-4" />
            <span>توضیحات و سناریوی دقیق</span>
          </label>
          <textarea
            value={scenario.detailedScenario}
            onChange={(e) => onScenarioChange({ ...scenario, detailedScenario: e.target.value })}
            className="w-full glass-input rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:ring-2 focus:ring-fuchsia-500/50 min-h-[120px] resize-y"
            placeholder="متن کامل، جزئیات، کال‌تو‌اکشن (CTA) و هر آنچه ادمین باید برای طراحی بداند..."
          />
        </div>

        <div className="pt-4 border-t border-white/10">
          <label className="block text-sm font-medium text-slate-300 mb-4 flex items-center justify-between">
            <span>تعداد استوری‌های درخواستی</span>
            <span className="text-2xl font-bold gradient-text">{storyCount}</span>
          </label>
          <div className="flex items-center gap-4">
            <input
              type="range"
              min="1"
              max="10"
              value={storyCount}
              onChange={(e) => onStoryCountChange(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-fuchsia-500"
            />
          </div>
          <div className="flex justify-between text-xs text-slate-500 mt-2 px-1">
            <span>۱ استوری</span>
            <span>۱۰ استوری</span>
          </div>
        </div>
      </div>
    </div>
  );
};