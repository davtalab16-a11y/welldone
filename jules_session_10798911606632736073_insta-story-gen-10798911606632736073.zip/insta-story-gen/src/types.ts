export interface TypographyStyle {
  fontFamily: string;
  fontSize: number; // in pixels or standard units
  color: string;
  weight: '300' | '400' | '500' | '600' | '700' | '800' | '900';
  textAlign: 'right' | 'center' | 'left' | 'justify';
  textShadow: string;
  style: 'normal' | 'italic';
  position: 'top' | 'middle' | 'bottom' | 'custom';
}

export interface UploadedImage {
  id: string;
  url: string;
  file: File;
}

export interface Scenario {
  campaignGoal: string;
  mainMessage: string;
  detailedScenario: string;
}

export interface Story {
  id: string;
  imageUrl: string;
  text: string;
  typography: TypographyStyle;
  backgroundStyle: string; // CSS background property (e.g. gradient or color)
  overlayOpacity: number;
}

export interface AppState {
  images: UploadedImage[];
  scenario: Scenario;
  storyCount: number;
  typography: TypographyStyle;
  generatedStories: Story[];
  isGenerating: boolean;
  generationStep: number;
}
