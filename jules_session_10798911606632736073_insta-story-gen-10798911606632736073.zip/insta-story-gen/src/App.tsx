import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Loader2 } from 'lucide-react';
import { useStoryGenerator } from './hooks/useStoryGenerator';
import { ImageUploader } from './components/ImageUploader';
import { ScenarioInput } from './components/ScenarioInput';
import { StyleEditor } from './components/StyleEditor';
import { StoryPreview } from './components/StoryPreview';

function App() {
  const {
    state,
    addImage,
    removeImage,
    setScenario,
    setStoryCount,
    setTypography,
    generateStories,
    updateStoryText,
  } = useStoryGenerator();

  const isReadyToGenerate = state.images.length > 0 && state.scenario.detailedScenario.trim().length > 0;

  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8 relative">
      {/* Background Orbs */}
      <div className="fixed top-[-10%] left-[-10%] w-[40%] h-[40%] bg-fuchsia-600/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="fixed bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-600/20 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center justify-center p-3 rounded-2xl glass-card mb-6">
            <Sparkles className="w-8 h-8 text-fuchsia-400" />
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-fuchsia-400 via-pink-300 to-indigo-400 mb-4 drop-shadow-sm">
            طراح استوری اینستاگرام (نسخه پرو)
          </h1>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            تصاویر رفرنس خود را آپلود کنید، سناریو را بنویسید و مانند یک ادمین حرفه‌ای، استوری‌های یکپارچه و زیبا تحویل بگیرید.
          </p>
        </motion.div>

        {/* Main Content Area */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left/Main Column - Inputs */}
          <div className="lg:col-span-8 space-y-8">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="glass-card rounded-3xl p-6 md:p-8 relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-fuchsia-500 to-transparent" />
              <ImageUploader 
                images={state.images}
                onAddImage={addImage}
                onRemoveImage={removeImage}
              />
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="glass-card rounded-3xl p-6 md:p-8 relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 to-transparent" />
              <ScenarioInput 
                scenario={state.scenario}
                onScenarioChange={setScenario}
                storyCount={state.storyCount}
                onStoryCountChange={setStoryCount}
              />
            </motion.div>
          </div>

          {/* Right Column - Style & Actions */}
          <div className="lg:col-span-4 space-y-8">
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="glass-card rounded-3xl p-6 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-full h-1 bg-gradient-to-l from-pink-500 to-transparent" />
              <StyleEditor 
                typography={state.typography}
                onTypographyChange={setTypography}
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <button
                onClick={generateStories}
                disabled={!isReadyToGenerate || state.isGenerating}
                className={`w-full py-5 rounded-2xl font-bold text-lg flex items-center justify-center gap-3 transition-all duration-300 relative overflow-hidden group ${
                  !isReadyToGenerate 
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    : 'bg-gradient-to-r from-fuchsia-600 to-indigo-600 text-white hover:shadow-[0_0_30px_rgba(217,70,239,0.4)] hover:scale-[1.02]'
                }`}
              >
                <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                <span className="relative z-10 flex items-center gap-2">
                  {state.isGenerating ? (
                    <>
                      <Loader2 className="w-6 h-6 animate-spin" />
                      در حال پردازش هوشمند...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-6 h-6" />
                      تولید استوری‌های حرفه‌ای
                    </>
                  )}
                </span>
              </button>
            </motion.div>
          </div>
        </div>

        {/* AI Generation Simulation Overlay */}
        <AnimatePresence>
          {state.isGenerating && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xl flex flex-col items-center justify-center"
            >
              <div className="relative w-32 h-32 mb-8">
                <div className="absolute inset-0 rounded-full border-t-4 border-fuchsia-500 animate-spin" />
                <div className="absolute inset-2 rounded-full border-r-4 border-indigo-500 animate-spin-reverse" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }} />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Sparkles className="w-10 h-10 text-fuchsia-400 animate-pulse" />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-white mb-2 text-glow">هوش مصنوعی در حال طراحی است...</h3>
              <div className="h-8 overflow-hidden relative">
                <motion.p
                  key={state.generationStep}
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: -20, opacity: 0 }}
                  className="text-fuchsia-300"
                >
                  {state.generationStep === 1 && "در حال آنالیز تصاویر و استخراج رنگ‌ها..."}
                  {state.generationStep === 2 && "ایجاد هارمونی و بک‌گراند مناسب..."}
                  {state.generationStep === 3 && "اعمال تایپوگرافی و جایگذاری متن..."}
                  {state.generationStep === 4 && "بهینه‌سازی نهایی و آماده‌سازی خروجی..."}
                </motion.p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Results */}
        <AnimatePresence>
          {state.generatedStories.length > 0 && !state.isGenerating && (
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-8"
            >
              <div className="w-full h-px bg-gradient-to-r from-transparent via-white/20 to-transparent my-12" />
              <StoryPreview 
                stories={state.generatedStories}
                onUpdateText={updateStoryText}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

export default App;