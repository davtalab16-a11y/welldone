import { useState, useCallback } from 'react';
import type { UploadedImage, Scenario, TypographyStyle, Story, AppState } from '../types';

const defaultTypography: TypographyStyle = {
  fontFamily: 'Vazirmatn',
  fontSize: 32,
  color: '#ffffff',
  weight: '700',
  textAlign: 'center',
  textShadow: '0px 4px 10px rgba(0,0,0,0.5)',
  style: 'normal',
  position: 'middle',
};

const defaultScenario: Scenario = {
  campaignGoal: '',
  mainMessage: '',
  detailedScenario: '',
};

export const useStoryGenerator = () => {
  const [state, setState] = useState<AppState>({
    images: [],
    scenario: defaultScenario,
    storyCount: 1,
    typography: defaultTypography,
    generatedStories: [],
    isGenerating: false,
    generationStep: 0,
  });

  const setImages = useCallback((images: UploadedImage[]) => {
    setState((prev) => ({ ...prev, images }));
  }, []);

  const addImage = useCallback((image: UploadedImage) => {
    setState((prev) => ({
      ...prev,
      images: prev.images.length < 10 ? [...prev.images, image] : prev.images,
    }));
  }, []);

  const removeImage = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      images: prev.images.filter((img) => img.id !== id),
    }));
  }, []);

  const setScenario = useCallback((scenario: Scenario) => {
    setState((prev) => ({ ...prev, scenario }));
  }, []);

  const setStoryCount = useCallback((count: number) => {
    setState((prev) => ({ ...prev, storyCount: Math.min(Math.max(1, count), 10) }));
  }, []);

  const setTypography = useCallback((typography: TypographyStyle) => {
    setState((prev) => ({ ...prev, typography }));
  }, []);

  const updateStoryText = useCallback((storyId: string, newText: string) => {
    setState((prev) => ({
      ...prev,
      generatedStories: prev.generatedStories.map((story) =>
        story.id === storyId ? { ...story, text: newText } : story
      ),
    }));
  }, []);

  const generateStories = useCallback(async () => {
    if (state.images.length === 0) return;

    setState((prev) => ({ ...prev, isGenerating: true, generationStep: 1 }));

    // Simulate AI Generation Process
    const steps = 4;
    for (let i = 2; i <= steps; i++) {
      await new Promise((resolve) => setTimeout(resolve, 1200));
      setState((prev) => ({ ...prev, generationStep: i }));
    }

    // Distribute images among stories
    const stories: Story[] = Array.from({ length: state.storyCount }).map((_, index) => {
      // Pick an image sequentially, loop if fewer images than stories
      const imageIndex = index % state.images.length;
      const image = state.images[imageIndex];

      // Generate a mock sophisticated gradient based on index
      const gradients = [
        'linear-gradient(135deg, rgba(15,23,42,0.9), rgba(88,28,135,0.8))',
        'linear-gradient(135deg, rgba(2,6,23,0.95), rgba(190,24,93,0.7))',
        'linear-gradient(to bottom, rgba(0,0,0,0.8), rgba(17,24,39,0.9))',
      ];
      
      // Simple logic to extract sentences from the scenario for each story
      const sentences = state.scenario.detailedScenario
        .split(/[.!?\n]/)
        .map(s => s.trim())
        .filter(s => s.length > 0);
        
      let text = state.scenario.mainMessage || 'داستان شما';
      if (sentences.length > 0) {
        text = sentences[index % sentences.length];
      }

      return {
        id: `story-${Date.now()}-${index}`,
        imageUrl: image.url,
        text,
        typography: state.typography,
        backgroundStyle: gradients[index % gradients.length],
        overlayOpacity: 0.4,
      };
    });

    setState((prev) => ({
      ...prev,
      generatedStories: stories,
      isGenerating: false,
      generationStep: 0,
    }));
  }, [state.images, state.storyCount, state.scenario, state.typography]);

  const reset = useCallback(() => {
    setState({
      images: [],
      scenario: defaultScenario,
      storyCount: 1,
      typography: defaultTypography,
      generatedStories: [],
      isGenerating: false,
      generationStep: 0,
    });
  }, []);

  return {
    state,
    setImages,
    addImage,
    removeImage,
    setScenario,
    setStoryCount,
    setTypography,
    generateStories,
    updateStoryText,
    reset,
  };
};