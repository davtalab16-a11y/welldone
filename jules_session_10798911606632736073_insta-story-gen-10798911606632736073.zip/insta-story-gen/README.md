# Insta Story Gen - Pro Admin

A professional, high-end React application designed for generating beautifully cohesive Instagram stories from user-uploaded images and a detailed scenario.

## Features
- **Upload Up to 10 Reference Images**: Drag and drop support.
- **Scenario & Campaign Goal Inputs**: Tell the AI what your story is about.
- **Advanced Typography Styling**: Choose fonts, weights, colors, alignment, and position.
- **Million-Dollar UI**: Glassmorphism, Framer Motion animations, and glowing aesthetics.
- **High-Quality Export**: Download the generated stories perfectly scaled.

## How to Run on Windows (or Mac/Linux)

### Prerequisites
1. **Node.js**: Make sure you have Node.js installed. If not, download and install the LTS version from [https://nodejs.org/](https://nodejs.org/).
2. **NPM**: This comes automatically when you install Node.js.

### Installation & Running

1. **Open Command Prompt (CMD) or PowerShell**:
   Press `Win + R`, type `cmd`, and press Enter.

2. **Navigate to the Project Folder**:
   Use the `cd` command to navigate to wherever you extracted or cloned this project.
   ```cmd
   cd path\to\insta-story-gen
   ```

3. **Install Dependencies**:
   Run the following command to download all required packages:
   ```cmd
   npm install
   ```

4. **Start the Application**:
   Run the development server:
   ```cmd
   npm run dev
   ```

5. **Open in Browser**:
   After running `npm run dev`, you will see a local URL in your terminal (usually `http://localhost:5173`). Copy that URL and paste it into your browser (Chrome, Edge, Firefox, etc.).

Enjoy creating professional Instagram stories!
